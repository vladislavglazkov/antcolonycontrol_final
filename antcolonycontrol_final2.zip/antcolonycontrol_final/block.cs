﻿#pragma once
namespace AntAlgo {
    public class BlockInfo
    {
        // public static void Main(string[] args) { }

        public double dist;
        public int type;
        public double angle;
        public int[] props = new int[1000];
        public void Init(double _dist, double _angle, int _type, int[] a)
        {
            this.dist = _dist;
            this.angle = _angle;
            this.type = _type;
            this.props = a;
        }
    }
}