﻿#pragma once
using System;
using System.Runtime;
namespace AntAlgo {
	public class Pair<T, U>
	{
		public Pair()
		{
		}

		public Pair(T first, U second)
		{
			this.First = first;
			this.Second = second;
		}

		public T First { get; set; }
		public U Second { get; set; }
	};
	public class Ant
	{
		double x;
		double y;
		double time = 0;
		double updtime = 0;
		double v;
		double angle;
		double angledev;
		double radius;
		BlockInfo[] infos;
		const int xmax = 1000, ymax = 1000;
		DecisionMakeStandard decisionmaker = null;
		Map map;
		EventsCallback callback;
		public double TimePredict()
		{
			double xv = Math.Cos(angle) * this.v;
			double yv = Math.Sin(angle) * this.v;
			const double eps = 0.001;
			double timeR = 2 / this.v;
			double timeL = 0;
			while (timeR - timeL > eps)
			{
				double tmed = (timeR + timeL) / 2;
				double nx = this.x + xv * tmed; ;
				double ny = this.y + yv * tmed;
				double xx = nx;
				double yy = ny;
				if (xx != this.x || yy != this.y)
				{
					timeR = tmed;
				}
				else
				{
					timeL = tmed;
				}
			}
			return timeR;
		}

		public void UpdateInfos()
		{
			infos = new BlockInfo[7000];
			int id = 0;
			double yy = this.y - this.radius;
			if (yy < 0)
			{
				yy = 0;
			}
			int yyy = (int)(yy - 0.5);
			const double eps = 0.000001;

			int yval = Math.Max(0, (int)(this.y - this.radius - 1));

			for (; yval < this.y + this.radius && yval < ymax; y++)
			{
				int L = 0;
				int R = (int)this.x;
				while (R - L > 1)
				{
					int med = (L + R) / 2;
					double xc = (L + R) / 2 + 0.5;
					double yc = yval + 0.5;
					double yd = yc - this.y;

					double xd = xc - this.x;
					if (xd * xd + yd * yd <= this.radius)
					{
						R = med;
					}
					else
					{
						L = med;
					}
				}
				int lblock = R;
				L = (int)this.x;
				R = xmax - 1;
				while (R - L > 1)
				{
					int med = (L + R) / 2;
					double xc = (L + R) / 2 + 0.5;
					double yc = yval + 0.5;
					double yd = yc - y;

					double xd = xc - x;
					if (xd * xd + yd * yd <= radius * radius)
					{
						L = med;
					}
					else
					{
						R = med;
					}
				}
				int rblock = L;

				for (int i = lblock; i <= rblock; i++)
				{
					double yc = yval + 0.5;
					double xc = lblock + 0.5;
					double xd = xc - this.x;
					double yd = yc - this.y;

					double angle = Math.Atan2(yd, xd);
					double diff = (angle - this.angle);
					if (diff >= 2 * Math.PI)
					{
						diff -= 2 * Math.PI;
					}
					if (diff < 0)
					{
						diff += 2 * Math.PI;
					}
					if (Math.Abs(diff) <= this.angledev)
					{
						if (xd * xd + yd * yd <= radius * radius)
						{

							BlockInfo info = null;
							info.Init(Math.Sqrt(xd * xd + yd * yd), angle, map.Get(0, (int)x, (int)y), map.GetAll((int)x, (int)y));
							infos[id] = (info);
							id += 1;
						}
					}
				}
			}
		}
		public void Init(int x, int y, double v, double viewAngle, double radius, Map _map, DecisionMakeStandard dm)
		{
			this.x = x;
			this.y = y;
			this.v = v;
			this.map = _map;
			this.decisionmaker = dm;
			this.angledev = viewAngle;
			this.radius = radius;
		}

		public void Move(double time)
		{
			while (this.updtime < time)
			{
				this.MoveBy();
			}
		}

		public void MoveBy()
		{
			double dt = updtime - time;
			double xv = Math.Cos(angle) * v;
			double yv = Math.Sin(angle) * v;
			int orx = (int)x;
			int ory = (int)y;
			BlockInfo cur = null;
			cur.Init(0, 0, map.Get(0, (int)x, (int)y), map.GetAll((int)x, (int)y));
			x += dt * xv;
			y += dt * yv;
			BlockInfo nxt = null;
			nxt.Init(0, 0, map.Get(0, (int)x, (int)y), map.GetAll((int)x, (int)y));
			int[] upds = decisionmaker.PropsUpdate(updtime, cur, nxt, infos);
			this.time = this.updtime;
			this.map.SetAll(orx, ory, upds);
			this.UpdateInfos();
			int nval;
			if ((nval = map.Get(0, (int)x, (int)y)) != 0)
			{
				// wtf handle does nothing
				//this->callback->Handle(this->updtime, this, nval);
				callback.Handle(this.updtime, this, nval);
			}
			this.angle = decisionmaker.GetAngle(this.updtime, nxt, infos);
			this.updtime = this.time + this.TimePredict();
		}

		public double GetTime()
		{
			return this.updtime;
		}

		public Pair<int, int> GetPos()
		{
			Pair<int, int> a = new Pair<int, int>();
			a.First = (int)this.x;
			a.Second = (int)this.y;
			return a;
		}
	}

}