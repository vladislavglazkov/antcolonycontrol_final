﻿#pragma once
using System;
using System.Runtime;
namespace AntAlgo {
	public class DecisionMakeStandard:DecisionMake
	{
		public int state = 0;
		public double GetAngle(double time, BlockInfo currentBlock, BlockInfo[] blocks)
		{
			double sum = 0;
			int n = blocks.Length;
			for (int i = 0; i < n; i++)
			{
				BlockInfo h = blocks[i];
				double val = 1 / (time - h.props[2 * (state ^ 1) + 1]) / h.dist;
				sum += val;
			}
			const double maxxx = 32767;
			double conversion = sum / (maxxx + 1);
			int rnd = new Random().Next(1);
			double ans = 0;
			sum = 0;
			for (int i = 0; i < n; i++)
			{
				BlockInfo h = blocks[i];
				double val = h.props[0] / h.dist;
				if ((sum + val) < conversion * rnd)
				{
					ans = h.angle;
				}
			}
			return ans;
		}
		public int[] PropsUpdate(double time, BlockInfo currentBlock, BlockInfo newBlock, BlockInfo[] blocks)
		{
			int[] ans = new int[9];
			if (state == 0)
			{
				ans[0] = 1;
				ans[1] = (int)time - 1;
			}
			else
			{
				ans[2] = 1;
				ans[3] = (int)time - 1;
			}

			if (state == 0 && newBlock.type == 2)
			{
				state = 1;
			}
			if (state == 1 && newBlock.type == 3)
			{
				state = 0;
			}

			return ans;
		}
	}


	public interface DecisionMake
	{
		public double GetAngle(double time, BlockInfo currentBlock, BlockInfo[] blocks);
		public int[] PropsUpdate(double time, BlockInfo currentBlock, BlockInfo newBlock, BlockInfo[] blocks);

	}
}