﻿#pragma once

namespace AntAlgo {
    public class Map
    {
        const int pnum = 10;

        static void Main(string[] args) { }
        public int xsz, ysz;
        public int[,,] vals = new int[pnum, 650, 370];

        public void Init(int xsz1, int ysz1, int types) {
            this.xsz = xsz1;
            this.ysz = ysz1;
        }
        public void Set(int type, int x, int y, int val) {
            this.vals[type, x, y] = val;
        }
        public int Get(int type, int x, int y) {
            return this.vals[type, x, y];
        }
        public void SetAll(int x, int y, int[] a) {
            int m = a.Length;
            for (int i = 0; i < m; i++)
            {
                this.vals[i + 1, x, y] = a[i];
            }
        }
        public int[] GetAll(int x, int y) {
            int[] a = new int[10];
            for (int i = 1; i < pnum; i++)
            {
                a[i] = this.Get(i, x, y);
            }
            return a;
        }
    }
}