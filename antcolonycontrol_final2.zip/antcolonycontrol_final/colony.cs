﻿#pragma once
using System;
using System.Collections.Generic;
namespace AntAlgo {
    public class AntColonyControl
    {
        SortedSet<Pair<double, Ant>> st;

        public void Move(double time)
        {
            while (st.Count > 0 && st.Min.Second.GetTime() < time)
            {
                Ant cur = st.Min.Second;
                Pair<double, Ant> next = null;
                next = st.Min;
                st.Remove(next);
                cur.MoveBy();
                Add(cur);
            }
        }
        public void Add(Ant aant)
        {
            Pair<double, Ant> a = new Pair<double, Ant>();
            a.First = aant.GetTime();
            a.Second = aant;
            st.Add(a);
        }
    }
}